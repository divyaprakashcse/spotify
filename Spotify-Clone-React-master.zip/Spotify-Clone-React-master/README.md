# Spotify Clone with React JS

This is the full stack working spotify clone created with React and Redux.

## Commands to Run after Cloning

In the project directory, you can run:

### `npm install`
### `npm start`

## Screenshots

![Screeshot 1](https://user-images.githubusercontent.com/94037749/166643114-dfe814eb-3996-446b-bdd3-61ff72e52411.png)

![Screenshot 2](https://user-images.githubusercontent.com/94037749/166643330-d23db656-1583-4f51-b6bf-730bc209206a.png)

## Thank You
